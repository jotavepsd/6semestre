package com.novosiga.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.novosiga.demo.entity.Aluno;
import com.novosiga.demo.services.AlunoService;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;


@Controller
@RequestMapping("/alunos")
public class
AlunoController {
    
    @Autowired
    private AlunoService alunoService;


    @PostMapping("/salvar")
    public String salvar(@ModelAttribute Aluno aluno,
                         @RequestParam("foto")MultipartFile foto) {

        try{
            if(!foto.isEmpty()){
                aluno.setFotoAluno(foto.getBytes());
                aluno.setTipoFoto(foto.getContentType());
            }
            alunoService.saveAluno(aluno);
        }catch (Exception e){
            e.printStackTrace();
        }
        return "redirect:/alunos/listar";
    }

    @GetMapping("/listar")
    public String listar(Model model) {
        List<Aluno> alunos = alunoService.findAll();
        model.addAttribute("alunos", alunos);
        return "aluno/listarAlunos";
    }

    @GetMapping("/criar")
    public String criarForm(Model model) {
        model.addAttribute("aluno", new Aluno());
        return "aluno/formularioAluno";
    }

    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Integer id) {
        alunoService.deletebyId(id);
        return "redirect:/alunos/listar";
    }

    @GetMapping("/editar/{id}")
    public String editarForm(@PathVariable Integer id, Model model) {
        Aluno aluno = alunoService.findById(id);
        model.addAttribute("aluno", aluno);
        return "aluno/formularioAluno";
    }

    @GetMapping("/foto/{id}")
    public ResponseEntity<byte[]> foto(@PathVariable Integer id) {
        Aluno aluno = alunoService.findById(id);

        if (aluno == null || aluno.getFotoAluno() == null) {
            return ResponseEntity.notFound().build();
        }

        MediaType tipo = MediaType.IMAGE_JPEG;
        if (aluno.getTipoFoto() != null && !aluno.getTipoFoto().isBlank()) {
            tipo = MediaType.parseMediaType(aluno.getTipoFoto());
        }

        return ResponseEntity.ok()
                .contentType(tipo)
                .body(aluno.getFotoAluno());
    }
}
