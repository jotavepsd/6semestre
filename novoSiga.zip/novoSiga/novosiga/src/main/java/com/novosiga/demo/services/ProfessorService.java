package com.novosiga.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.novosiga.demo.entity.Professor;
import com.novosiga.demo.repository.ProfessorRepository;

@Service
public class ProfessorService {

    @Autowired
    private ProfessorRepository professorRepository;

    public Professor saveProfessor(Professor professor) { return professorRepository.save(professor); }
    public List<Professor> findAll() { return professorRepository.findAll(); }
    public void deletebyId(Integer id) { professorRepository.deleteById(id); }
    public Professor findById(Integer id) { return professorRepository.findById(id).orElse(null); }
}
