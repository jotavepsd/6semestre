package com.novosiga.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.novosiga.demo.entity.Aluno;
import com.novosiga.demo.repository.AlunoRepository;

@Service
public class AlunoService {
    
    @Autowired
    private AlunoRepository alunoRepository;

    public Aluno saveAluno(Aluno aluno) {
        return alunoRepository.save(aluno);
    }

    public List<Aluno> findAll() {
        return alunoRepository.findAll();
    }


    public void deletebyId(Integer id) {
        alunoRepository.deleteById(id);
    }

    public Aluno findById(Integer id) {
        return alunoRepository.findById(id).orElse(null);
    }
}
