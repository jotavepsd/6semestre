package com.novosiga.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.novosiga.demo.entity.Disciplina;
import com.novosiga.demo.repository.DisciplinaRepository;

@Service
public class DisciplinaService {

    @Autowired
    private DisciplinaRepository disciplinaRepository;

    public Disciplina saveDisciplina(Disciplina disciplina) { return disciplinaRepository.save(disciplina); }
    public List<Disciplina> findAll() { return disciplinaRepository.findAll(); }
    public void deletebyId(Integer id) { disciplinaRepository.deleteById(id); }
    public Disciplina findById(Integer id) { return disciplinaRepository.findById(id).orElse(null); }
}
