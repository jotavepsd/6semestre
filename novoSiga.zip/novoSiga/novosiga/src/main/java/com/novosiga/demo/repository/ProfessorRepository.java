package com.novosiga.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.novosiga.demo.entity.Professor;

public interface ProfessorRepository extends JpaRepository<Professor, Integer> {
}
