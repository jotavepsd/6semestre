package com.novosiga.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.novosiga.demo.entity.Disciplina;

public interface DisciplinaRepository extends JpaRepository<Disciplina, Integer> {
}
