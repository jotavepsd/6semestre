package com.novosiga.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.novosiga.demo.entity.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Integer> {
    
}
