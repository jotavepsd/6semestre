package com.novosiga.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class Aluno {


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer idAluno;

    @Column(nullable = false, length = 50)
    private String nomeAluno;
    
    @Column(nullable = false, length = 40)
    private String enderecoAluno;
    
    @Column(nullable = false, length = 40)
    private String bairroAluno;

    @Column(nullable = false, length = 30)
    private String cidadeAluno;
    
    @Column(nullable = false, length = 02)
    private String estadoAluno;
    
    @Column(nullable = false, length = 8)
    private String cepAluno;
    
    @Column(nullable = false, length = 11)
    private String telefoneAluno;
    
    @Column(nullable = false, length = 11)
    private String cpfAluno;

    @Lob
    private byte[] fotoAluno;

    private String tipoFoto;
}
