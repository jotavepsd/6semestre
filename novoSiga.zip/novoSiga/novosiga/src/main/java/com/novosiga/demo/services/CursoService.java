package com.novosiga.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.novosiga.demo.entity.Curso;
import com.novosiga.demo.repository.CursoRepository;

@Service
public class CursoService {

    @Autowired
    private CursoRepository cursoRepository;

    public Curso saveCurso(Curso curso) { return cursoRepository.save(curso); }
    public List<Curso> findAll() { return cursoRepository.findAll(); }
    public void deletebyId(Integer id) { cursoRepository.deleteById(id); }
    public Curso findById(Integer id) { return cursoRepository.findById(id).orElse(null); }
}
